import UIKit

var ogrenciAdi = "Yasin"
var ogrenciSoyadi = "KARATEKE"
var ogrenciYasi = 26
var ogrenciBoyu = 1.76
var ogrenciBasHarfi = "Y"
var ozelSayi = 3.45

print(ogrenciAdi)
print(ogrenciSoyadi)
print(ogrenciYasi)
print(ogrenciBoyu)
print(ogrenciBasHarfi)


var urun_id: Int = 3416
var urun_adi: String = "Kol Saati"
var urun_adet: Int = 100
var urun_fiyat: Double = 149.99
var urun_tedarikci: String = "Rolex"

print(urun_id)
print(urun_adi)
print(urun_adet)
print(urun_fiyat)
print(urun_tedarikci)

print("Öğrencimizin adı \(ogrenciAdi), soyadı \(ogrenciSoyadi), boyu \(ogrenciBoyu), ve öğrencimizin yaşı \(ogrenciYasi)'dır")

var sayi = 10

var numara:Int?

numara = 20

print(numara!)

//ornekler

var sayi1 = 30 , sayi2 = 40 , kelime = "Merhaba", harf = "f"


print(sayi1)
print(sayi2)
print(kelime)
print(harf)

var fiyat = 12.99

print(fiyat)

fiyat = 19.99

print(fiyat)

//

var s1 = 80
var s2 = 70

var toplam = s1 - s2

print(toplam)

//

var sonuc = 100

sonuc = 50


class Deneme{
    
    var x = 10
    var y = 90
    
    func topla (){
        var x = 40
        var y = 60
        
        x = x - y
        
        print(x)
    }
    
    func carp(){
        x = x * y
        
        print(x)
        
    }
    
}

var d = Deneme()

d.topla()
d.carp()


var sayilar = 10

sayilar = 100

print(sayilar)


let pi = 3.0001444

let klorOrani: Double = 4.55988777

let ismim = "Yasiniko"


//yeni alanlara yolculuk

/* awdawdawd */

var yazi = "Mehmet \"ali abiye\" nasılsın?"

//print(yazi)


var text = "Merhaba bu \"ios\"\n\teğitiminde \\swift\\ dilini öğreniyorum."

print(text)


//yeni hesaplamalr

var pic = 3.14

var yariCap = 2.0

var alan = pic * yariCap * yariCap

print(alan)

//kuvvetler

var m = 12.5
var a = 10.0
var f = m * a

print(f)


//AX

var v = 12.7
var v0 = 23.56
var t = 3.5

var x1 = ((v + v0)/2)*t

print(x1)

var x2 = (v0*t) + (a*t*t)/2

print(x2)

//kısatlamalar

var y = 10

y = y + 2

print(y)

y+=2
print(y)

y-=3
print(y)

y*=4
print(y)

y/=2
print(y)

//

var i:Int = 42
var das:Double = 42.45
var ffas:Float = 42.89

var sonuc1:Int = Int(das)
var sonuc2:Double = Double(i)
var sonuc3:Int = Int(ffas)

print(sonuc1)
print(sonuc2)
print(sonuc3)

var str1 = String(i)
var str2 = String(das)
var str3 = String(ffas)

print(str1)
print(str2)
print(str3)


//metinden sayısala dönüşüm

var yazi1 = "34"

if let sayi1 = Int(yazi1){
    print(sayi1)
}


var kisiler = ("Ahmet","Ali","Harun")
var soyadlar = ("Yıldırım","Buğa","Akalın")

var kullanici = kisiler.1
var kullaniciSoyadi = soyadlar.1

print(kullanici + kullaniciSoyadi)
print(kullaniciSoyadi)

var hataMesajı = (404, "Buluanamadı")

var (kod,mesaj) = hataMesajı

print(hataMesajı)


var ogrenci: (Int,(Bool,String)) = (1256, (true,"Ahmet"))

print(ogrenci.0)
print(ogrenci.1)


var ali = 31

var yasi = "yasin"


//değişkenlerle çalışmalar


var s3 = 50
var s4 = 50

var y1 = 90
var y2 = 40

print(s1 == s2)
print(s1 > s2)
print(s1 >= y1)
print(s1 != s2)

print(s1>s2)

print(s1>s2 && y1>y2)

//if else yapısı hakkında

var yas = 19
var isminiz = "Yasin"


if yas >= 18 {
    print("Reşitsiniz")
}


//else if

if yas >= 19 {
    print("reşitsin")
}else{
    print("reşit değilsin knk")
}


if isminiz == "Yasin"{
    print("Merhaba yasiniko")
}else{
    print("siktir lan kimsin sen")
}

if isminiz == "Yasin"{
    print("merhaba yasin")
    
}else if isminiz == "Mehmet"{
    print("merhaba mehmetim")
    
}else{
    "kimsin sen"
    
}

//

var kullaniciAdi = "admin"
var sifrem = 12345

if sifrem == 12345 && kullaniciAdi == "admin"{
    print("hoşgeldiniz")
}else{
    print("hatalı oldu galiba...")
}

var sinif = 10

if sinif == 9 || sinif == 10 || sinif == 12{
    print("AYT sınavına hazırlan")
}

//ornek 8 Ternary Coditinoal

var ab = 10
var bb = 20

ab == bb ? print("koşul sağlandı") : print("eşit değildir.")
